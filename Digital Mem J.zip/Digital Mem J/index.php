
<!DOCTYPE html>
<html>
<head>
    <title>Memory App</title>
    <style>
        /* Reset some default styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* Body styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        /* Container for the app */
        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        /* App header styles */
        .header {
            text-align: center;
            background-color: #007bff;
            color: #fff;
            padding: 20px;
        }

        /* Form styles */
        form {
            padding: 20px;
            border: 1px solid #ccc;
            background-color: #fff;
        }

        label {
            display: block;
            margin: 10px 0;
        }

        input[type="text"],
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="file"] {
            display: block;
            margin: 10px 0;
        }

        button {
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        /* Timeline entry styles */
        .memory-entry {
            border: 1px solid #ccc;
            background-color: #fff;
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }

        /* Media query for responsiveness */
        @media (max-width: 600px) {
            .container {
                max-width: 100%;
            }
        }
    </style>
</head>

<body>
    <div class="container">
        <div class="header">
            <h1>Memory App</h1>
        </div>
        
        <div>
            <h2>Create a Memory Entry</h2>
            <form>
                <label for="text">Text Description:</label>
                <textarea id="text" rows="4" cols="50"></textarea>
                
                <?php if (isset($_GET['error'])): ?>
		<p><?php echo $_GET['error']; ?></p>
	<?php endif ?>
     <form action="upload.php"
           method="post"
           enctype="multipart/form-data">

           <input type="file" 
                  name="my_image">

           <input type="submit" 
                  name="submit"
                  value="Upload">
     	
     </form>
                <label for="location">Location:</label>
                <input type="text" id="location">
                <button type="submit">Save Memory</button>
            </form>
        </div>

        <div>
            <h2>Timeline View</h2>
            <div class="memory-entry">
                <p>Date: 2023-11-01 12:00 PM</p>
                <p>This is a sample memory entry. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                <p>Location: Sample Location</p>
            </div>
            <div class="memory-entry">
                <p>Date: 2023-11-01 10:00 AM</p>
                <p>Another memory entry goes here.</p>
                <p>Location: Another Location</p>
            </div>
            <!-- Add more memory entries here -->
        </div>
    </div>
</body>
</html>
